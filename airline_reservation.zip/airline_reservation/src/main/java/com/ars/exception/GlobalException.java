package com.ars.exception;

//GlobalException and runtime exception
public class GlobalException extends RuntimeException{
	public GlobalException(String message)
	{
		super(message);
	}

}
